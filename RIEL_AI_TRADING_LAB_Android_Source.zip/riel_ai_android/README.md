# RIEL AI TRADING LAB — Android APK starter

A free, Android-installable WebView app for **paper/backtest simulation only**.

## Current functions
- Strategy simulation labelled Riel Continuation + Break & Retest
- Backtest metrics: simulated PnL, win rate, max drawdown, profit factor
- Entry, stop loss, take profit, risk sizing, trade log and equity curve
- CSV import for OHLC candles
- Fetch up to 500 public Binance 4-hour candles for the symbol in the field (default BTCUSDT)
- No exchange login, no API keys, and no real-money orders

## Important limitations
- “AI analysis” is currently a transparent rule-based strategy engine, not a connected external AI model.
- Live data is fetched only when the user taps the button; this is not a continuously updating feed.
- Backtest is educational and not evidence of future performance. It does not model fees, funding, slippage, or exchange-specific execution.
- This first APK is an unsigned debug build. Android may show a warning when installing it; install only the APK you built from this source.

## Build APK for free using only an Android phone
1. Download and extract this ZIP.
2. Open GitHub in your browser and create a new repository named `riel-ai-trading-lab`.
3. Upload the **contents** of this folder to the repository root (make sure `.github/workflows/build-apk.yml` is included). GitHub's website may make folder uploads awkward; if needed, use the GitHub mobile site in desktop mode or the free `github.dev` editor.
4. Open the repository's **Actions** tab. Select **Build Android APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `RIEL-AI-TRADING-LAB-debug-apk`.
6. Extract the downloaded artifact ZIP; inside is `app-debug.apk`. Tap it to install and allow your browser/files app to install unknown apps if Android asks.

## Build locally
Requires Android SDK and Gradle 8.9 with JDK 17. Run `gradle assembleDebug`; APK output is `app/build/outputs/apk/debug/app-debug.apk`.
